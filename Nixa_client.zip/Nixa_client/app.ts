import express from 'express';
import { NextFunction } from "express";
import { Request } from "express";
import { Response } from "express";
import http from 'http';
import path from 'path';
import { listeControleur } from './app/src/serveur/controleurs/listeControleur';
import { ajouterControleur } from './app/src/serveur/controleurs/ajouterControleur';
import { effacerControleur } from './app/src/serveur/controleurs/effacerControleur';


let exp = express();
let server = http.createServer(exp);
server.listen(3001);
console.log("\nServeur sur le port 3001");
exp.enable('trust proxy');

exp.use(express.static(__dirname+"/app/src"));//to get also css, js, images, ...
exp.use(express.urlencoded({extended: false}));
exp.use(express.json()) // To parse the incoming requests with JSON payloads


exp.get('/', async (req:Request, res:Response)=>{
	res.sendFile(path.join(__dirname +'/app/src/index.html'));
});


exp.all('/lister',async (req:Request, res:Response, next:NextFunction) => {
	try{
		let ctrReponse = await listeControleur.ctr_liste();
		res.header('Content-type','application/json');
		res.header('Charset','utf8');
		res.send(ctrReponse);//Envoyer réponse au client
	}catch(erreur){
		console.log(erreur)
		next({ name: 'connexion', message: 'Problème pour traiter la requête connexion' });
	}
});

exp.all('/ajouter',async (req:Request, res:Response, next:NextFunction) => {
	try{
		let ctrReponse = await ajouterControleur.ctr_ajouter(req);
		res.header('Content-type','application/json');
		res.header('Charset','utf8');
		res.send(ctrReponse);//Envoyer réponse au client
	}catch(erreur){
		console.log(erreur)
		next({ name: 'connexion', message: 'Problème pour traiter la requête connexion' });
	}
});

exp.all('/effacer',async (req:Request, res:Response, next:NextFunction) => {
	try{
		let ctrReponse = await effacerControleur.ctr_effacer(req);
		res.header('Content-type','application/json');
		res.header('Charset','utf8');
		res.send(ctrReponse);//Envoyer réponse au client
	}catch(erreur){
		console.log(erreur)
		next({ name: 'connexion', message: 'Problème pour traiter la requête connexion' });
	}
});

exp.use(( erreur: any, req: Request, res: Response, next: NextFunction ) : void =>{
    switch (erreur.name){
		case "connexion":
            res.send(erreur.message);
        break;
    }
});

