
const requete_serveur = async(action) => {
    switch (action) {
        case "lister":
            await $.ajax({
                    type: 'GET',
                    url: '/lister',
                    async: false
                })
                .done((reponse) => {
                    listerCard(reponse);
                   
                })
                .fail(() => {
                    alert("Erreur!");
                })
                
        break;
        
        case "envoyer":
            let form =document.getElementById('form_ajouter');

            await $.ajax({
                type: 'POST',
                url: '/ajouter',
                data: {nom:form.children[1].value,prenom:form.children[3].value,telephone:form.children[5].value,date_contact:form.children[7].value},
                async: false
            })
            .done(() => {
                requete_serveur('lister');
               
            })
            .fail(() => {
                alert("Erreur!");
            })
        break;
        case "effacer":
            let form_effacer =document.getElementById('form_effacer');
            await $.ajax({
                type: 'POST',
                url: '/effacer',
                data: {dossier:form_effacer.children[1].value},
                async: false
            })
            .done(() => {
                requete_serveur('lister');
               
            })
            .fail(() => {
                alert("Erreur!");
            })
        break;
    }
}


function effacer_cree()
{
    let div = document.getElementById("main");
    div.innerHTML = "";
    let form = document.createElement('form');
    form.id = "form_effacer";
    let in_effacer= document.createElement('input');
    let div_effacer = document.createElement('div');
    div_effacer.innerHTML="dossier a effacer";
    let button = document.createElement('button');
    let br = document.createElement('br');
    button.innerHTML="effacer";
    button.type="submit";
    button.className="btn-primary";

    form.appendChild(div_effacer);
    form.appendChild(in_effacer);
    form.appendChild(br);
    form.appendChild(button);
    div.appendChild(form);
    button.addEventListener("click",()=>{requete_serveur('effacer')});
}

function ajout()
{
    let div = document.getElementById("main");
    div.innerHTML = "";
    let form = document.createElement('form');
    form.id = "form_ajouter";
    let in_nom= document.createElement('input');
    let in_prenom = document.createElement('input');
    let in_tele = document.createElement('input');
    let in_date_conct = document.createElement('input');
    let div_nom = document.createElement('div');
    let div_prenom = document.createElement('div');
    let div_tele = document.createElement('div');
    let div_date_conct = document.createElement('div');
    let br = document.createElement('br');
    let button = document.createElement('button');
    button.innerHTML="soumettre";
    button.type="submit";
    button.className="btn-primary";
    
    div_nom.innerHTML = "nom ";
    div_prenom.innerHTML = "prenom ";
    div_tele.innerHTML = "telephone ";
    div_date_conct.innerHTML = "date de contact ";

    
    form.appendChild(div_nom);
    form.appendChild(in_nom);
    form.appendChild(div_prenom);
    form.appendChild(in_prenom);
    form.appendChild(div_tele);
    form.appendChild(in_tele);
    form.appendChild(div_date_conct);
    form.appendChild(in_date_conct);
    form.appendChild(br);
    form.appendChild(button);
    div.appendChild(form);
    button.addEventListener("click",()=>{requete_serveur('envoyer')});

}


function listerCard(reponse)
{
    let div = document.getElementById("main");
    div.innerHTML="";
    for(let i=0;i<reponse.length;i++)
    {
        let div_card = document.createElement('div');
		let div_card_header = document.createElement('div');
		let div_card_body = document.createElement('div');
        div_card.style ='color:rgb(3,3,80);weight:900;font-size:20px;display:block;float:left;text-align:center;background-color: transparent';
		div_card.className = 'card col-sm-12 card_detail';
        div_card_header.className = 'card-header no_border';
		div_card_body.className ='card-bodoy no_border';

        div_card_header.innerHTML=reponse[i].dossier;
        div_card_body.innerHTML=reponse[i].prenom+"  "+reponse[i].nom+" tel: "+reponse[i].telephone+" date : "+reponse[i].date_contact;
		
		div_card_header.appendChild(div_card_body);
		div_card.appendChild(div_card_header);
		div.appendChild(div_card);
    }
}




