let model = (valeur) =>{
    return  valeur+10;
}

let service = (valeur) =>{
    return  model(valeur);
}

let controleur = (valeur) =>{
    return  service(valeur);
}

let serveur = (valeur) =>{
    return  controleur(valeur);
}

let client = () =>{
    let reponse = serveur(30);
    console.log("Réponse du serveur = "+reponse);
} 

let TroisTiers = () => {
    client();
}

//Démarrer le système
TroisTiers();