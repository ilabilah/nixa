let montrer = (idElem) => {
    document.getElementById(idElem).style.display = 'block';
}

let cacher = (idElem) => {
    document.getElementById(idElem).style.display = 'none';
}