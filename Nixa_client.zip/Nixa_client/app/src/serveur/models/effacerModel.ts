import { connexion } from "./config/dbconf";

export class ModelEffacer{
  static async Mdl_effacer(dossier: any): Promise<object> {
    const effacer_dossier = "DELETE FROM tabclients WHERE dossier='"+dossier.dossier+"';";
    let reponse = await connexion.queryAsync( effacer_dossier); 
    return reponse;
      
  }
}
