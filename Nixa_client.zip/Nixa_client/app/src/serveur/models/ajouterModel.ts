import { connexion } from "./config/dbconf";

export class ModelAjouter{
  static async Mdl_ajouter(data_patients: any): Promise<object> {
   
    const insert_patients = "INSERT INTO  tabclients (nom,prenom,telephone,date_contact) VALUES ('"+data_patients.nom+"','"+data_patients.prenom+"','"+data_patients.telephone+"','"+data_patients.date_contact+"')";
    let reponse = await connexion.queryAsync( insert_patients); 
    return reponse;
      
  }
}
