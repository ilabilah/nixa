import { connexion } from "./config/dbconf";

export class ModelListe{
  static async Mdl_liste(): Promise<object> {
   
    let reponse;   
    const requeteSelection = "SELECT * FROM tabclients ";
    reponse = await connexion.queryAsync(requeteSelection); 
    return reponse;
      
  }
}
