import mysql from 'mysql';
import bluebird from "bluebird";
bluebird.promisifyAll(mysql);//Rendre function avec promesses

let connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'nixaClients'
});

export let connexion:any = bluebird.promisifyAll(connection);