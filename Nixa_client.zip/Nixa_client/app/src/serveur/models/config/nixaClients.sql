
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
create database nixaClients;
use nixaClients;





CREATE TABLE `tabclients` (
  `dossier` int(11) NOT NULL,
  `prenom` varchar(30) DEFAULT NULL,
  `nom` varchar(30) DEFAULT NULL,
  `telephone` varchar(30) DEFAULT NULL,
  `date_contact` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `tabclients` (`dossier`, `prenom`, `nom`,`telephone`,`date_contact`) VALUES
(1, 'Emille', 'Leger','438-465-8764','2002-05-02'),
(2, 'Marie', 'Bernard','438-455-8764','2022-05-02'),
(3, 'Guy', 'Chartrand','438-465-8864','2022-05-02'),
(4, 'Andre', 'Cote','438-465-8764','2022-05-02'),
(5, 'Carole', 'Lavoie','438-265-8764','2002-05-02'),
(6, 'Diane', 'Martin','428-465-8764','2012-05-02'),
(7, 'Pauline', 'Lacroix','438-465-9764','2022-05-02');



ALTER TABLE `tabclients`
  ADD PRIMARY KEY (`dossier`);


ALTER TABLE `tabclients`
  MODIFY `dossier` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

