export declare var connection: any;
