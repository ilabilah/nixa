import { Service_liste } from "../services/listeService";

export class listeControleur {
  static ctr_liste = async (): Promise<object> => {
        return await Service_liste.Srv_liste();
  };
}
