import { Request } from "express";
import { Service_effacer } from "../services/effacerService";

export class effacerControleur {

  static ctr_effacer = async (req: Request):  Promise<object> => {
        let dossier = req.body;
       // console.log("dans controleur le dossier par req.body = "+dossier);
        return await Service_effacer.Srv_effacer(dossier);
  };
}
