import { Request } from "express";
import { Service_ajouter } from "../services/ajouterService";

export class ajouterControleur {

  static ctr_ajouter = async (req: Request):  Promise<object> => {
        let data_patients = req.body;
        return await Service_ajouter.Srv_ajouter(data_patients);
  };
}
