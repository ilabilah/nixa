import { ModelAjouter } from "../models/ajouterModel";

export class Service_ajouter {
  static Srv_ajouter = async (data_patients: any): Promise<object> => {
     return await ModelAjouter.Mdl_ajouter(data_patients);
  };
}
