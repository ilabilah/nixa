import { ModelEffacer } from "../models/effacerModel";

export class Service_effacer {
  static Srv_effacer = async (dossier: any): Promise<object> => {
     return await ModelEffacer.Mdl_effacer(dossier);
  };
}
