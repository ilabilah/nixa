import { ModelListe } from "../models/listeModel";

export class Service_liste {
  static Srv_liste = async (): Promise<object> => {
     return await ModelListe.Mdl_liste();
  };
}
